import * as React from "react"
import { cn } from "@/lib/utils"

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "inline-flex items-center justify-center whitespace-nowrap rounded-full text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary disabled:pointer-events-none disabled:opacity-50",
          {
            'bg-brand-primary text-brand-light hover:bg-brand-primary/90': variant === 'primary',
            'bg-brand-secondary text-brand-dark hover:bg-brand-secondary/90': variant === 'secondary',
            'border border-brand-dark/20 bg-transparent hover:bg-brand-dark hover:text-brand-light': variant === 'outline',
            'hover:bg-brand-dark/5 text-brand-dark': variant === 'ghost',
            'h-9 px-4 py-2': size === 'sm',
            'h-11 px-6 py-2': size === 'md',
            'h-14 px-8 py-3 text-base': size === 'lg',
          },
          className
        )}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button }
