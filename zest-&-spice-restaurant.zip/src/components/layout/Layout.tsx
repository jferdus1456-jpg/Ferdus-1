import { Outlet } from "react-router-dom";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
import { ScrollRestoration } from "react-router-dom";

export function Layout() {
  return (
    <div className="flex flex-col min-h-screen">
      <ScrollRestoration />
      <Navbar />
      <main className="flex-grow pt-24 md:pt-0"> {/* Add padding top for mobile to account for fixed navbar without breaking hero on desktop */}
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
