import { Link } from "react-router-dom";
import { Facebook, Instagram, Twitter, MapPin, Phone, Mail } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-brand-dark text-brand-light/80 pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="font-serif text-3xl font-bold text-brand-light">Zest & Spice</h3>
            <p className="max-w-xs leading-relaxed">
              Delicious Food, Cozy Experience. A journey of flavors serving the finest mixed cuisine with a touch of elegance.
            </p>
            <div className="flex gap-4 pt-2">
              <a href="#" className="hover:text-brand-secondary transition-colors"><Facebook size={20} /></a>
              <a href="#" className="hover:text-brand-secondary transition-colors"><Instagram size={20} /></a>
              <a href="#" className="hover:text-brand-secondary transition-colors"><Twitter size={20} /></a>
            </div>
          </div>

          {/* Opening Hours */}
          <div className="space-y-4">
            <h4 className="font-serif text-xl font-semibold text-brand-light">Opening Hours</h4>
            <ul className="space-y-2">
              <li className="flex justify-between max-w-[200px]">
                <span>Mon - Thu:</span>
                <span>11:00 AM - 10:00 PM</span>
              </li>
              <li className="flex justify-between max-w-[200px]">
                <span>Fri - Sat:</span>
                <span>11:00 AM - 11:30 PM</span>
              </li>
              <li className="flex justify-between max-w-[200px]">
                <span>Sunday:</span>
                <span>12:00 PM - 10:00 PM</span>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-serif text-xl font-semibold text-brand-light">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link to="/" className="hover:text-brand-secondary transition-colors text-sm uppercase tracking-wider">Home</Link></li>
              <li><Link to="/menu" className="hover:text-brand-secondary transition-colors text-sm uppercase tracking-wider">Our Menu</Link></li>
              <li><Link to="/about" className="hover:text-brand-secondary transition-colors text-sm uppercase tracking-wider">About Us</Link></li>
              <li><Link to="/contact" className="hover:text-brand-secondary transition-colors text-sm uppercase tracking-wider">Contact</Link></li>
              <li><Link to="/reservation" className="hover:text-brand-secondary transition-colors text-sm uppercase tracking-wider">Book a Table</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h4 className="font-serif text-xl font-semibold text-brand-light">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex gap-3">
                <MapPin size={20} className="shrink-0 text-brand-secondary" />
                <span>123 Culinary Hub, Flavor Street,<br/>City, Country</span>
              </li>
              <li className="flex gap-3 items-center">
                <Phone size={20} className="shrink-0 text-brand-secondary" />
                <span>+1 234 567 8900</span>
              </li>
              <li className="flex gap-3 items-center">
                <Mail size={20} className="shrink-0 text-brand-secondary" />
                <span>hello@zestandspice.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-brand-light/10 pt-8 mt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm">
          <p>&copy; {new Date().getFullYear()} Zest & Spice Restaurant. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-brand-light transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-brand-light transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
