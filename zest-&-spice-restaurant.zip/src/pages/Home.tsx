import { motion } from "motion/react";
import { Button } from "@/components/ui/Button";
import { Link } from "react-router-dom";
import { Star } from "lucide-react";

export default function Home() {
  const featuredDishes = [
    {
      name: "Truffle Mushroom Risotto",
      description: "Creamy arborio rice with wild mushrooms and truffle oil.",
      price: "$24",
      image: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?q=80&w=800&h=800&auto=format&fit=crop"
    },
    {
      name: "Gourmet Fusion Burger",
      description: "Wagyu beef patty with caramelized onions and aged cheddar.",
      price: "$18",
      image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=800&h=800&auto=format&fit=crop"
    },
    {
      name: "Raspberry Chocolate Tart",
      description: "Decadent dark chocolate shell with fresh raspberry coulis.",
      price: "$12",
      image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?q=80&w=800&h=800&auto=format&fit=crop"
    }
  ];

  const testimonials = [
    {
      name: "Sarah Jenkins",
      rating: 5,
      review: "Absolutely phenomenal experience! The flavors are perfectly balanced, and the ambiance is so inviting."
    },
    {
      name: "Michael Chen",
      rating: 5,
      review: "Best restaurant in the city. The service is impeccable and the truffle risotto is a must-try."
    },
    {
      name: "Emily Rodriguez",
      rating: 5,
      review: "A wonderful place for family dinners. The staff was incredibly accommodating and the food was delicious."
    }
  ];

  return (
    <div className="-mt-24 md:mt-0"> {/* Offset mobile padding for full screen hero */}
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?q=80&w=1920&h=1080&auto=format&fit=crop" 
            alt="Delicious food spread on a rustic table" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-brand-dark/70" /> {/* Dark overlay */}
        </div>
        
        <div className="container relative z-10 mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-3xl mx-auto space-y-6"
          >
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif text-brand-light font-bold leading-tight">
              Delicious Food, <br />
              <span className="text-brand-secondary italic font-light">Cozy Experience.</span>
            </h1>
            <p className="text-lg md:text-xl text-brand-light/90 max-w-xl mx-auto font-light">
              Experience a blend of exotic flavors and warm hospitality in the heart of the city. 
              Taste the passion in every bite.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
              <Link to="/menu">
                <Button variant="primary" size="lg" className="w-full sm:w-auto">Order Now</Button>
              </Link>
              <Link to="/reservation">
                <Button variant="outline" size="lg" className="w-full sm:w-auto border-brand-light text-brand-light hover:bg-brand-light hover:text-brand-dark">Book a Table</Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Dishes Section */}
      <section className="py-24 bg-brand-light">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-brand-secondary text-sm font-semibold tracking-[0.2em] uppercase mb-4">Our Specials</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold text-brand-dark mb-6">Discover Our Signature Dishes</h3>
            <p className="text-brand-dark/70 leading-relaxed">
              Carefully crafted by our expert chefs, our signature dishes represent the perfect harmony of taste, texture, and presentation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredDishes.map((dish, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group rounded-2xl overflow-hidden bg-white shadow-[0_8px_30px_rgb(0,0,0,0.04)] transition-all hover:shadow-[0_8px_30px_rgb(0,0,0,0.08)]"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img 
                    src={dish.image} 
                    alt={dish.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-8 text-center">
                  <h4 className="text-2xl font-serif font-semibold text-brand-dark mb-2">{dish.name}</h4>
                  <p className="text-brand-dark/70 mb-4">{dish.description}</p>
                  <p className="text-xl font-bold text-brand-primary">{dish.price}</p>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link to="/menu">
              <Button variant="secondary">View Full Menu</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Ambiance/About snippet section */}
      <section className="py-24 bg-brand-dark text-brand-light">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="w-full lg:w-1/2 order-2 lg:order-1 relative">
              <div className="aspect-[4/5] rounded-tl-[100px] rounded-br-[100px] overflow-hidden">
                 <img 
                  src="https://images.unsplash.com/photo-1514933651103-005eec06c04b?q=80&w=1200&h=1500&auto=format&fit=crop" 
                  alt="Restaurant interior"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              {/* Decorative element */}
              <div className="absolute -bottom-8 -left-8 w-32 h-32 border-2 border-brand-secondary rounded-full -z-10 hidden md:block"></div>
            </div>
            
            <div className="w-full lg:w-1/2 order-1 lg:order-2 space-y-6">
              <h2 className="text-brand-secondary text-sm font-semibold tracking-[0.2em] uppercase mb-2">Our Story</h2>
              <h3 className="text-4xl md:text-5xl font-serif font-bold mb-6 leading-tight">
                A Journey of Flavors & Tradition
              </h3>
              <p className="text-brand-light/80 text-lg font-light leading-relaxed mb-6">
                Founded with a passion for exceptional culinary experiences, Zest & Spice brings together the finest ingredients, time-honored recipes, and warm hospitality. 
              </p>
              <p className="text-brand-light/80 leading-relaxed mb-8">
                Whether you're joining us for a family celebration or an intimate dinner, our cozy atmosphere and diverse menu promise a memorable time for food lovers.
              </p>
              <Link to="/about">
                <Button variant="outline" className="border-brand-light text-brand-light hover:bg-brand-light hover:text-brand-dark">Read More</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-brand-light">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-brand-secondary text-sm font-semibold tracking-[0.2em] uppercase mb-4">Testimonials</h2>
            <h3 className="text-4xl font-serif font-bold text-brand-dark">What Our Guests Say</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="bg-brand-light p-8 rounded-2xl border border-brand-dark/10"
              >
                <div className="flex gap-1 mb-6 text-brand-secondary">
                  {[...Array(testimonial.rating)].map((_, j) => (
                    <Star key={j} size={18} fill="currentColor" />
                  ))}
                </div>
                <p className="text-brand-dark/80 italic mb-6 leading-relaxed">
                  "{testimonial.review}"
                </p>
                <p className="font-serif font-bold text-brand-dark text-lg">
                  - {testimonial.name}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
