import { motion } from "motion/react";

export default function Menu() {
  const menuCategories = [
    {
      category: "Starters",
      items: [
        { name: "Crispy Calamari", description: "Served with zesty lemon garlic aioli.", price: "$12" },
        { name: "Bruschetta Classic", description: "Toasted sourdough with marinated tomatoes and fresh basil.", price: "$9" },
        { name: "Spicy Chicken Wings", description: "Glazed in our signature sweet chili sauce.", price: "$11" },
        { name: "Stuffed Mushrooms", description: "Filled with cream cheese, herbs, and parmesan.", price: "$10" },
      ]
    },
    {
      category: "Main Course",
      items: [
        { name: "Grilled Salmon", description: "Wild caught salmon with roasted asparagus and lemon butter.", price: "$26" },
        { name: "Chicken Tikka Masala", description: "Tender chicken in a rich, creamy tomato gravy with naan.", price: "$22" },
        { name: "Truffle Mushroom Risotto", description: "Creamy arborio rice with wild mushrooms and truffle oil.", price: "$24" },
        { name: "Ribeye Steak", description: "12oz grass-fed beef cooked to perfection, with mashed potatoes.", price: "$34" },
      ]
    },
    {
      category: "Desserts",
      items: [
        { name: "Classic Tiramisu", description: "Layered mascarpone and espresso-soaked ladyfingers.", price: "$9" },
        { name: "Raspberry Chocolate Tart", description: "Decadent dark chocolate shell with fresh raspberry coulis.", price: "$10" },
        { name: "Mango Panna Cotta", description: "Silky Italian cream dessert topped with fresh mango puree.", price: "$8" },
      ]
    },
    {
      category: "Drinks",
      items: [
        { name: "Fresh Mint Lemonade", description: "House-made lemonade infused with fresh mint leaves.", price: "$5" },
        { name: "Classic Mojito", description: "White rum, fresh lime juice, mint, and soda.", price: "$10" },
        { name: "Artisan Coffee", description: "Freshly brewed Colombian roast.", price: "$4" },
        { name: "Masala Chai", description: "Traditional spiced Indian tea.", price: "$4" },
      ]
    }
  ];

  return (
    <div className="bg-brand-light min-h-screen pt-12 pb-24">
      <div className="container mx-auto px-4 md:px-6 max-w-4xl">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-serif font-bold text-brand-dark mb-4">Our Menu</h1>
          <div className="w-24 h-1 bg-brand-primary mx-auto mb-6"></div>
          <p className="text-brand-dark/70 text-lg">
            Discover a world of flavors crafted with passion and the finest ingredients.
          </p>
        </motion.div>

        <div className="space-y-16">
          {menuCategories.map((cat, index) => (
            <motion.div 
              key={cat.category}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 + (index * 0.1) }}
            >
              <h2 className="text-3xl font-serif font-bold text-brand-primary mb-8 pb-4 border-b border-brand-dark/10 text-center md:text-left">
                {cat.category}
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
                {cat.items.map((item) => (
                  <div key={item.name} className="flex flex-col group">
                    <div className="flex justify-between items-baseline mb-2 relative">
                      <h3 className="text-xl font-serif font-bold text-brand-dark pr-4 bg-brand-light relative z-10">{item.name}</h3>
                      <div className="absolute inset-0 flex items-center z-0">
                         <div className="w-full border-b border-dotted border-brand-dark/30"></div>
                      </div>
                      <span className="text-xl font-bold text-brand-primary pl-4 bg-brand-light relative z-10">{item.price}</span>
                    </div>
                    <p className="text-brand-dark/70 text-sm leading-relaxed">{item.description}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
