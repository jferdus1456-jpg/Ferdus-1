import { motion } from "motion/react";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { Button } from "@/components/ui/Button";

export default function Contact() {
  return (
    <div className="bg-brand-light min-h-screen pt-12 pb-24">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.6 }}
           className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-serif font-bold text-brand-dark mb-4">Contact Us</h1>
          <div className="w-24 h-1 bg-brand-primary mx-auto mb-6"></div>
          <p className="text-brand-dark/70 text-lg max-w-2xl mx-auto">
            We'd love to hear from you. Get in touch with us for any inquiries or feedback.
          </p>
        </motion.div>

        <div className="flex flex-col lg:flex-row gap-12 lg:gap-20">
          {/* Contact Info */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="w-full lg:w-1/3 space-y-10"
          >
            <div>
              <h2 className="text-2xl font-serif font-bold text-brand-dark mb-6">Get in Touch</h2>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-brand-primary/10 p-3 rounded-full text-brand-primary mt-1">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-brand-dark mb-1">Our Location</h3>
                    <p className="text-brand-dark/70">123 Culinary Hub, Flavor Street,<br />Metropolis, MC 10012</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="bg-brand-primary/10 p-3 rounded-full text-brand-primary mt-1">
                    <Phone size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-brand-dark mb-1">Phone Number</h3>
                    <p className="text-brand-dark/70">+1 (234) 567-8900</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-brand-primary/10 p-3 rounded-full text-brand-primary mt-1">
                    <Mail size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-brand-dark mb-1">Email Address</h3>
                    <p className="text-brand-dark/70">hello@zestandspice.com</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-serif font-bold text-brand-dark mb-6">Opening Hours</h2>
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-brand-dark/5">
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-brand-dark/80">
                    <span className="font-medium">Mon - Thu</span>
                    <span>11:00 AM - 10:00 PM</span>
                  </div>
                  <div className="w-full h-px bg-brand-dark/10"></div>
                  <div className="flex justify-between items-center text-brand-dark/80">
                    <span className="font-medium">Fri - Sat</span>
                    <span>11:00 AM - 11:30 PM</span>
                  </div>
                  <div className="w-full h-px bg-brand-dark/10"></div>
                  <div className="flex justify-between items-center text-brand-dark/80">
                    <span className="font-medium">Sunday</span>
                    <span>12:00 PM - 10:00 PM</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* WhatsApp Button */}
            <a href="https://wa.me/12345678900" target="_blank" rel="noreferrer" className="inline-flex w-full">
              <Button variant="secondary" className="w-full flex gap-2 bg-[#25D366] text-white hover:bg-[#1ebe57]">
                <Phone size={18} /> Chat on WhatsApp
              </Button>
            </a>
          </motion.div>

          {/* Contact Form */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="w-full lg:w-2/3"
          >
            <div className="bg-white p-8 md:p-12 rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.06)]">
              <h2 className="text-3xl font-serif font-bold text-brand-dark mb-8">Send Us a Message</h2>
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium text-brand-dark">Full Name</label>
                    <input 
                      type="text" 
                      id="name" 
                      className="w-full h-12 px-4 rounded-xl border border-brand-dark/20 bg-brand-light/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all"
                      placeholder="John Doe"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium text-brand-dark">Email Address</label>
                    <input 
                      type="email" 
                      id="email" 
                      className="w-full h-12 px-4 rounded-xl border border-brand-dark/20 bg-brand-light/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all"
                      placeholder="john@example.com"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm font-medium text-brand-dark">Subject</label>
                  <input 
                    type="text" 
                    id="subject" 
                    className="w-full h-12 px-4 rounded-xl border border-brand-dark/20 bg-brand-light/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all"
                    placeholder="How can we help you?"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium text-brand-dark">Message</label>
                  <textarea 
                    id="message" 
                    rows={5}
                    className="w-full p-4 rounded-xl border border-brand-dark/20 bg-brand-light/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all resize-none"
                    placeholder="Write your message here..."
                  ></textarea>
                </div>

                <Button variant="primary" size="lg" className="w-full md:w-auto">
                  Send Message
                </Button>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
