import { motion } from "motion/react";

export default function About() {
  return (
    <div className="bg-brand-light min-h-screen pt-12 pb-24">
      {/* Header */}
      <div className="container mx-auto px-4 md:px-6 mb-20 text-center">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.6 }}
        >
          <h1 className="text-5xl md:text-6xl font-serif font-bold text-brand-dark mb-4">Our Story</h1>
          <div className="w-24 h-1 bg-brand-primary mx-auto mb-6"></div>
          <p className="text-brand-dark/70 text-lg max-w-2xl mx-auto">
            A passion for culinary excellence and a warm, inviting atmosphere.
          </p>
        </motion.div>
      </div>

      <div className="container mx-auto px-4 md:px-6">
        {/* Story Section */}
        <div className="flex flex-col lg:flex-row items-center gap-16 mb-24">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="w-full lg:w-1/2"
          >
            <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl relative">
              <img 
                src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=1200&h=900&auto=format&fit=crop" 
                alt="Restaurant interior"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="w-full lg:w-1/2 space-y-6"
          >
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-brand-dark">Tradition Meets Innovation</h2>
            <p className="text-brand-dark/80 text-lg leading-relaxed">
              Founded in 2015, Zest & Spice began as a small family endeavor with a big dream: to create a dining experience that feels like coming home, but tastes like an adventure.
            </p>
            <p className="text-brand-dark/80 leading-relaxed">
              We travel the world to source the finest ingredients, bringing global inspiration back to our kitchen. Every dish is a labor of love, combining traditional cooking techniques with modern culinary innovation.
            </p>
            <p className="text-brand-dark/80 leading-relaxed font-serif italic text-xl border-l-4 border-brand-primary pl-4 py-2 mt-4">
              "We don't just serve food; we serve memories."
            </p>
          </motion.div>
        </div>

        {/* Team Section */}
        <div className="bg-white rounded-3xl p-8 md:p-16 shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="w-full lg:w-3/5 space-y-6 order-2 lg:order-1"
            >
              <h2 className="text-brand-secondary text-sm font-semibold tracking-[0.2em] uppercase mb-2">Meet Our Head Chef</h2>
              <h3 className="text-3xl md:text-4xl font-serif font-bold text-brand-dark">Arjun Sharma</h3>
              <p className="text-brand-dark/80 text-lg leading-relaxed">
                With over two decades of experience in Michelin-starred kitchens across Europe and Asia, Chef Arjun brings an unparalleled level of expertise and creativity to Zest & Spice.
              </p>
              <p className="text-brand-dark/80 leading-relaxed">
                His philosophy is simple: let the ingredients speak for themselves. By focusing on seasonal, locally-sourced produce, he crafts menus that perfectly balance bold flavors with delicate presentation.
              </p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="w-full lg:w-2/5 order-1 lg:order-2"
            >
              <div className="aspect-[3/4] rounded-[2rem] overflow-hidden shadow-xl border-8 border-brand-light">
                 <img 
                  src="https://images.unsplash.com/photo-1583394838036-ac2804ebbede?q=80&w=800&h=1000&auto=format&fit=crop" 
                  alt="Head Chef"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
