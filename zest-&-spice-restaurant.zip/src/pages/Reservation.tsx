import { motion } from "motion/react";
import { Button } from "@/components/ui/Button";

export default function Reservation() {
  return (
    <div className="bg-brand-light min-h-screen pt-12 pb-24">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.6 }}
           className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-serif font-bold text-brand-dark mb-4">Book a Table</h1>
          <div className="w-24 h-1 bg-brand-primary mx-auto mb-6"></div>
          <p className="text-brand-dark/70 text-lg max-w-2xl mx-auto">
            Reserve your spot for an unforgettable dining experience. 
            For parties larger than 8, please contact us directly.
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto bg-white rounded-[2rem] overflow-hidden shadow-[0_20px_60px_rgb(0,0,0,0.08)] flex flex-col md:flex-row">
          {/* Form Side */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="w-full md:w-3/5 p-8 md:p-12"
          >
            <h2 className="text-3xl font-serif font-bold text-brand-dark mb-8">Reservation Details</h2>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="res-name" className="text-sm font-medium text-brand-dark">Full Name</label>
                  <input 
                    type="text" 
                    id="res-name" 
                    className="w-full h-12 px-4 rounded-xl border border-brand-dark/20 bg-brand-light/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all"
                    placeholder="John Doe"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="res-phone" className="text-sm font-medium text-brand-dark">Phone Number</label>
                  <input 
                    type="tel" 
                    id="res-phone" 
                    className="w-full h-12 px-4 rounded-xl border border-brand-dark/20 bg-brand-light/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all"
                    placeholder="+1 234 567 8900"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="res-date" className="text-sm font-medium text-brand-dark">Date</label>
                  <input 
                    type="date" 
                    id="res-date" 
                    className="w-full h-12 px-4 rounded-xl border border-brand-dark/20 bg-brand-light/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="res-time" className="text-sm font-medium text-brand-dark">Time</label>
                    <input 
                      type="time" 
                      id="res-time" 
                      className="w-full h-12 px-4 rounded-xl border border-brand-dark/20 bg-brand-light/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="res-guests" className="text-sm font-medium text-brand-dark">Guests</label>
                    <select 
                      id="res-guests" 
                      className="w-full h-12 px-4 rounded-xl border border-brand-dark/20 bg-brand-light/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all"
                    >
                      {[1,2,3,4,5,6,7,8].map(num => (
                        <option key={num} value={num}>{num} {num === 1 ? 'Person' : 'People'}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="res-notes" className="text-sm font-medium text-brand-dark">Special Requests (Optional)</label>
                <textarea 
                  id="res-notes" 
                  rows={3}
                  className="w-full p-4 rounded-xl border border-brand-dark/20 bg-brand-light/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all resize-none"
                  placeholder="Allergies, anniversaries, high chair requirements..."
                ></textarea>
              </div>

              <div className="pt-4">
                <Button variant="primary" size="lg" className="w-full shadow-lg shadow-brand-primary/20">
                  Confirm Reservation
                </Button>
              </div>
            </form>
          </motion.div>
          
          {/* Image Side */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="hidden md:block w-2/5 relative"
          >
            <img 
              src="https://images.unsplash.com/photo-1559339352-11d035aa65de?q=80&w=800&h=1200&auto=format&fit=crop" 
              alt="Restaurant table setup"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-brand-dark/80 to-transparent flex items-end p-8">
              <p className="text-brand-light font-serif italic text-xl">
                "Dining is not just about food, it's about the company and the memories made."
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
